package com.example.goodapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int Zamalek = 0;
    int ahly = 0;
    int foulsza = 0;
    int foulsah = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForZamalak(0);
        displayForahly(0);
        displayForZamalak(0);
        foulsah(0);
    }

    public void displayForZamalak(int score) {
        TextView scoreView = (TextView) findViewById(R.id.textah);
        scoreView.setText(String.valueOf(score));
    }

    public void btnp1za(View view) {
        Zamalek = Zamalek + 1;
        displayForZamalak(Zamalek);
    }
    public void btnp2za(View view) {
        Zamalek = Zamalek + 2;
        displayForZamalak(Zamalek);
    }
    public void foulsza(int score) {
        TextView scoreView = (TextView) findViewById(R.id.textView2);
        scoreView.setText(String.valueOf(score));
    }

    public void foulsza(View view) {
        foulsza = foulsza + 1;
        foulsza(foulsza);
    }

    public void displayForahly(int score) {
        TextView scoreView = (TextView) findViewById(R.id.textza);
        scoreView.setText(String.valueOf(score));
    }

    public void btnp1ah(View view) {
        ahly = ahly + 1;
        displayForahly(ahly);
    }
    public void btnp2ah(View view) {
        ahly = ahly + 2;
        displayForahly(ahly);
    }
    public void foulsah(int score) {
        TextView scoreView = (TextView) findViewById(R.id.textView3);
        scoreView.setText(String.valueOf(score));
    }

    public void foulsah(View view) {
        foulsah = foulsah + 1;
        foulsah(foulsah);
    }

    public void btngo(View view) {
        Zamalek = 0;
        ahly = 0;
        foulsza = 0;
        foulsah = 0;
        displayForZamalak(Zamalek);
        displayForahly(ahly);
        foulsza(foulsza);
        foulsah(foulsah);

    }
}



